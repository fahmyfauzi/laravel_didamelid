# Jadwal-Sholat
Menampilkan jadwal solat harian berserta lokasinya

<div align="center">
   <img width="300" src="https://storage.cloudconvert.com/tasks/418b5c9e-7c87-41b1-b898-75f45e53038a/feriirawan.herokuapp.com.jpg?AWSAccessKeyId=cloudconvert-production&Expires=1625472808&Signature=4Sji8WS3i1FJqzXXhVsh3yGqlEU%3D&response-content-disposition=inline%3B%20filename%3D%22feriirawan.herokuapp.com.jpg%22&response-content-type=image%2Fjpeg">
</div>
